﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyTestNamespace;

namespace CoachCSharpConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            Pig myPig = new Pig(); // Create a Pig object
            //myPig.animalSound();  // Call the abstract method
            //myPig.sleep();
            myPig.dayOfWeek();

            //Animal myAnimal = new Animal();  // Create a Animal object
            //Animal myPig = new Pig();  // Create a Pig object
            //Animal myDog = new Dog();  // Create a Dog object

            //myAnimal.animalSound();
            //myPig.animalSound();
            //myDog.animalSound();


            //string[] cars = { "Volvo", "BMW", "Ford", "Mazda" };
            //for (int ii = 0; ii < cars.Length; ii++)
            //{
            //    if (ii == 2)
            //    {
            //        continue;
            //    }
            //    if (ii == 3)
            //    {
            //        break;
            //    }

            //    Console.WriteLine(cars[ii]);
            //}

            //Console.WriteLine("Enter Number");
            //int num = Convert.ToInt32(Console.ReadLine());



            //MyTestNamespace.Car Ford = new MyTestNamespace.Car("Ford", "Mustang", "red", 1969);



            //MyTestNamespace.Car FordExplorer = new MyTestNamespace.Car();
            ////FordExplorer.Company = "Ford";
            //FordExplorer.model = "Ford Explorer";
            //FordExplorer.color = "blue";
            //FordExplorer.year = 2020;

            //MyTestNamespace.Car Opel = new MyTestNamespace.Car();
            //Opel.company = "Fiat";
            //Opel.model = "Astra";
            //Opel.color = "white";
            //Opel.year = 2005;

            //MyTestNamespace.Car Bmw = new MyTestNamespace.Car();
            //Bmw.company = "BMW";
            //Bmw.model = "X350";
            //Bmw.color = "black";
            //Bmw.year = 2020;

            //Console.WriteLine(Ford.model);
            //Console.WriteLine(FordExplorer.Company);
            //FordExplorer.honk();
            //Console.WriteLine(Opel.model);
            //Console.WriteLine(Bmw.model);

            //int[] a = { 5, 10, 2, 45, 26, 30, 5 };
            ////int[] res = CoachCSharpLibrary.Sort.Bubble(a);
            //int[] res = CoachCSharpLibrary.Math.BubbleSort(a);
            //foreach (var i in res)
            //{
            //    Console.WriteLine(i);
            //}




            //Console.WriteLine("Exp1 Sum of 2 and 5 = " + CoachCSharpLibrary.Math.Sum(2, 8));


            //Examples exp = new Examples();
            //exp.FibnnociSeries(num);
            //Console.WriteLine("Sum of 2 and 5 = " + exp.Sum(Convert.ToDecimal(2), Convert.ToDecimal(2), Convert.ToDecimal(2)));
            //Console.WriteLine("Exp1 Sum of 2 and 5 = " + MyTestNamespace.Examples.Sum(2, 8));
            //Console.WriteLine("Sum of 2 and 5 = " + exp.Sum(2, 11));
            //Console.WriteLine("Exp1 Sum of 2 and 5 = " + MyTestNamespace.Examples.Sum(2, 15));


            Console.ReadLine();
        }
    }
    class Examples
    {
        public void FibnnociSeries(int num, bool isPrint = true)
        {
            //Fibbnoci seriese
            int l = 0, j = 1, k, i;
            i = 2;
            do
            {
                k = j + l;
                if (isPrint)
                {
                    Console.WriteLine(k + " ");
                }
                l = j;
                j = k;
                i++;
            }
            while (i < num);
        }
        public int Sum(int x, int y)
        {
            return x + y;
        }
        public int Sum(int x, int y, int z)
        {
            return x + y + z;
        }
        public decimal Sum(decimal x, decimal y, decimal z)
        {
            return x + y + z;
        }
    }
}
