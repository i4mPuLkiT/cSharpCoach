﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTestNamespace
{
    class Examples
    {
        public  static void FibnnociSeries(int num, bool isPrint = true)
        {
            //Fibbnoci seriese
            int l = 0, j = 1, k, i;
            i = 2;
            do
            {
                k = j + l;
                if (isPrint)
                {
                    Console.WriteLine(k + " ");
                }
                l = j;
                j = k;
                i++;
            }
            while (i < num);
        }
        public static int Sum(int x,int y)
        {
            return x + y;
        }
        public static int Sum(int x, int y, int z)
        {
            return x + y + z;
        }
        public static decimal Sum(decimal x, decimal y, decimal z)
        {
            return x + y + z;
        }
    }
    class  Vehicle  // base class (parent) 
    {
        public string brand = "Ford";  // Vehicle field
        public void honk()             // Vehicle method 
        {
            Console.WriteLine("Tuut, tuut!");
        }
    }
    class Car: Vehicle
    {
        private string company="My company";
        public string model;
        public string color;
        public int year;
        public string Company   // property
        {
            get { return company; }   // get method
            //set { company = value; }  // set method
        }
        public Car(string company, string model, string color, int year)
        {
            this.company = company;
            this.model = model;
            this.color = color;
            this.year = year;
            Console.WriteLine($"In side constructot Class init.. {company}  {model}  {color}  {year}");
        }
        public Car()
        {
            Console.WriteLine($"In side constructot Class init..");
        }
        public void fullThrottle()
        {
            Console.WriteLine("The car is going as fast as it can!");
        }
    }

    abstract class Animal  // Base class (parent) 
    {
        // Abstract method (does not have a body)
        public abstract void animalSound();
        // Regular method
        public void sleep()
        {
            Console.WriteLine("Zzz");
        }
    }
    // Interface
    interface IAnimal
    {
        void animalSound(); // interface method (does not have a body)
        void dayOfWeek();
    }
    interface IAnimalS
    {
        void sleep();
    }

    class Pig : IAnimal, IAnimalS //Multiple Inheritance
    {
        enum DayOfWeek
        {
            Sunday = 1,
            Monday = 2,
            Tuesday = 3,
            Wednesday = 4,
            Thursday = 5,
            Friday = 6,
            Saturday = 7
        }

        public void animalSound()
        {
            Console.WriteLine("The pig says: wee wee");
        }

        public void sleep()
        {
            Console.WriteLine("Zzz");
        }

        public void dayOfWeek()
        {
            try
            {
                Console.WriteLine("Enter day of week [Between 0-6] : ");
                string d = Console.ReadLine();
                //if ((DayOfWeek)d == DayOfWeek.Sunday)
                //{
                //    Console.WriteLine(DayOfWeek.Sunday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Monday)
                //{
                //    Console.WriteLine(DayOfWeek.Monday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Tuesday)
                //{
                //    Console.WriteLine(DayOfWeek.Tuesday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Wednesday)
                //{
                //    Console.WriteLine(DayOfWeek.Wednesday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Thursday)
                //{
                //    Console.WriteLine(DayOfWeek.Thursday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Friday)
                //{
                //    Console.WriteLine(DayOfWeek.Friday.ToString());
                //}
                //else if ((DayOfWeek)d == DayOfWeek.Saturday)
                //{
                //    Console.WriteLine(DayOfWeek.Saturday.ToString());
                //}
                switch (Convert.ToInt32(d))
                {
                    case (int)DayOfWeek.Monday:
                        Console.WriteLine(DayOfWeek.Monday.ToString());
                        break;
                    case (int)DayOfWeek.Tuesday:
                        Console.WriteLine(DayOfWeek.Tuesday.ToString());
                        break;
                    case (int)DayOfWeek.Wednesday:
                        Console.WriteLine(DayOfWeek.Wednesday.ToString());
                        break;
                    case (int)DayOfWeek.Thursday:
                        Console.WriteLine(DayOfWeek.Thursday.ToString());
                        break;
                    case (int)DayOfWeek.Friday:
                        Console.WriteLine(DayOfWeek.Friday.ToString());
                        break;
                    case (int)DayOfWeek.Saturday:
                        Console.WriteLine(DayOfWeek.Saturday.ToString());
                        break;
                    case (int)DayOfWeek.Sunday:
                        Console.WriteLine(DayOfWeek.Sunday.ToString());
                        break;
                    default:
                        Console.WriteLine("Not Found");
                        break;
                }

                ////Uglly code
                //switch (d)
                //{
                //    case 0:
                //        Console.WriteLine("Monday");
                //        break;
                //    case 1:
                //        Console.WriteLine("Tuesday");
                //        break;
                //    case 2:
                //        Console.WriteLine("Wednesday");
                //        break;
                //    case 3:
                //        Console.WriteLine("Thursday");
                //        break;
                //    case 4:
                //        Console.WriteLine("Friday");
                //        break;
                //    case 5:
                //        Console.WriteLine("Saturday");
                //        break;
                //    case 6:
                //        Console.WriteLine("Sunday");
                //        break;
                //    default:
                //        Console.WriteLine("Not Found");
                //        break;
                //}
            }
            catch (Exception ex)
            {
                string messge= $"Erro messge : {ex.Message}";
                Console.WriteLine(messge);
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"c:\temp\errorLog.txt", true))
                {
                    file.WriteLine(DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff tt") + " - " + messge);//ITODOL;
                }
            }
        }
    }

    class Dog : Animal  // Derived class (child) 
    {
        public override void animalSound()
        {
            Console.WriteLine("The dog says: bow wow");
        }
    }

}
