﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoachCSharpLibrary
{
    public class Math
    {
        public static int Sum(int x, int y)
        {
            return x + y;
        }
        public static int Sum(int x, int y, int z)
        {
            return x + y + z;
        }
        public static decimal Sum(decimal x, decimal y, decimal z)
        {
            return x + y + z;
        }
        public static int[] BubbleSort(int[] a)
        {
            return Sort.Bubble(a);
        }

    }
    public class Sort
    {
        internal static int[] Bubble(int[] a)
        {
            for (int i = 0; i < a.Length-1 ; i++)
            {
                for (int j = 0; j < (a.Length -1) - i; j++)
                {
                    if (a[j] > a[j + 1])
                    {
                        int temp = a[j];
                        a[j] = a[j + 1];
                        a[j + 1] = temp;
                    }
                }
            }
            return a;
        }
    }
}
