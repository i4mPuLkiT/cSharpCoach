﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoachCSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreateTable_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtTableNo.Text))
            {
                table();
            }
            else
            {
                MessageBox.Show("Please Enter No.");
                txtTableNo.Focus();
            }
        }
        private void table()
        {
            string temp = "30";
            const int myNum = 15;
            Console.WriteLine(Convert.ToInt32(temp).ToString());

            int no = int.Parse(txtTableNo.Text);
            const int TABLE_LIMIT = 10;
            listBox1.Items.Clear();
            for (int i = 1; i <= TABLE_LIMIT; i++)
            {
                result.Text = (no * i).ToString();
                listBox1.Items.Add($"{no} * {i} = {result.Text}");
            }
            result.Visible = true;
        }
    }
}
